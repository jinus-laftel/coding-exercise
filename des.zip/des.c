/*
 * des.c	v1.0
 *
 * Copyleft 2001 Jinius. All Rights Unreserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * for NON-COMMERCIAL purpose is hereby granted.
 *
 * http://kuls.korea.ac.kr/~jinius/
 * http://jin.wo.to/
 *
 * email : jiniuskorea@hanmail.net
 */

#include <stdlib.h>
#include "des.h"
#include "bit.h"

void permute(const unsigned char *input, unsigned char *output, const int *mapping, const int mapsize)
{
	unsigned char *buffer;
	int i;

	buffer = (unsigned char *)malloc((mapsize+7) / 8);		/* buffer allocate */

	for(i = 0; i < mapsize; i++)
		set_bit(buffer, i, get_bit(input, mapping[i] - 1));

	memcpy(output, buffer, (mapsize+7) / 8);

	free(buffer);
}

/* key generator */
void set_subkey(unsigned char subkey[16][6], const unsigned char *key)
{
	unsigned char buffer[7];
	unsigned char lkey[4], rkey[4];
	int i;
	memset(lkey, 0, 4);		/* fill with 0 */
	memset(rkey, 0, 4);

	permute(key, buffer, pc1, 56);

	/* Devide 56-bit block to two 28-bit block */
	for(i = 0; i < 28; i++) {
		set_bit(lkey, i, get_bit(buffer, i));
		set_bit(rkey, i, get_bit(buffer, i + 28));
	}

	/* generate 16 subkey */
	for(i = 0; i < 16; i++) {
		left_rotate(lkey, rotate[i], 28);
		left_rotate(rkey, rotate[i], 28);

		for(i = 0; i < 28; i++) {
			set_bit(buffer, i, get_bit(lkey, i));
			set_bit(buffer, i + 28, get_bit(rkey, i));
		}

		/* export 'i'th subkey */
		permute(buffer, subkey[i], pc2, 48);
	}
}

/* One of 16 round in DES main function */
void round(unsigned char *lblock, unsigned char *rblock, const unsigned char *subkey)
{
	unsigned char buffer[6];
	int i;

	permute(rblock, buffer, e, 48);
	xor_bit(buffer, subkey, buffer, 48);
	sbox(buffer);
	permute(buffer, buffer, p32, 32);
	xor_bit(buffer, lblock, buffer, 32);

	memcpy(lblock, rblock, 4);
	memcpy(rblock, buffer, 4);
}

/* S-box */
void sbox(unsigned char *data)
{
	unsigned char buffer[4];
	unsigned char temp;
	int i, j;
	int row, col;

	for(i = 0; i < 8; i++) {
		row = (get_bit(data, i * 6) << 1) + get_bit(data, i * 6 + 5);
		col = (get_bit(data, i * 6 + 2) << 3) + (get_bit(data, i * 6 + 2) << 2) + (get_bit(data, i * 6 + 2) << 1) + (get_bit(data, i * 6 + 2));
		temp = s_box[row][col];

		for(j = 0; j < 4; j++)
			set_bit(buffer, i * 4 + j, get_bit(&temp, j + 4));
	}

	memcpy(data, buffer, 4);

	return;
}

void des_encipher(const unsigned char *plaintext, unsigned char *ciphertext, const unsigned char *key)
{
	des_main(plaintext, ciphertext, key, encipher);
}

void des_decipher(const unsigned char *ciphertext, unsigned char *plaintext, const unsigned char *key)
{
	des_main(ciphertext, plaintext, key, decipher);
}

static int des_main(const unsigned char *input, unsigned char *output, const unsigned char *key, DesOrder direction)
{
	static unsigned char subkey[16][6];
	unsigned char buffer[8];
	int i;

	if(key != NULL) set_subkey(subkey, key);
	permute(input, buffer, ip, 64);

	for(i = 0; i < 16; i++) {
		if(direction == encipher)
			round(buffer, buffer + 4, subkey[i]);
		else round(buffer, buffer + 4, subkey[15 - i]);
	}

	memcpy(output, buffer + 4, 4);
	memcpy(output + 4, buffer, 4);

	permute(output, output, fp, 64);

	return 0;
}
